# Sistema de Biblioteca em Java

Projeto de console para praticar orientação a objetos em Java.

## Funcionalidades
- Cadastrar livros
- Listar livros
- Pesquisar por título
- Emprestar livros
- Devolver livros
- Impedir empréstimos duplicados

## Estrutura
```text
SistemaBiblioteca/
├── src/
│   ├── Main.java
│   ├── Livro.java
│   └── Biblioteca.java
└── README.md
```

## Como executar
1. Abra a pasta do projeto na sua IDE.
2. Execute `src/Main.java`.
3. Os arquivos Java não usam `package`, então podem ficar juntos no mesmo diretório.

**Nota:** os dados são mantidos apenas enquanto o programa está aberto. Eles não são salvos em um banco de dados.
